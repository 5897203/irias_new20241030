/// <reference types="vite/client" />
declare module 'react-helmet-async';